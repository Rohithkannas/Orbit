ORBIT v1.4.0 - COMPLETE PROJECT

IMPORTANT: This is the project source, not a prebuilt installer.

START CLEANLY ON WINDOWS
1. Close every old Orbit window.
2. Close old Orbit terminal windows/dev servers (especially old Vite servers).
3. Extract this ZIP into a NEW folder, for example C:\Orbit-v1.4.0.
4. Confirm package.json is directly inside that folder. Do not run an older folder.
5. Double-click RUN-ORBIT-WINDOWS.bat.
6. Keep the terminal open while using Orbit.

The window should show v1.4.0. If it shows v0.1.0, you launched an old copy or old process.

AI ASSISTANT
- Install/start Ollama and pull a model, e.g. `ollama pull qwen3:8b`.
- In Orbit Settings -> AI Assistant, use http://localhost:11434 and qwen3:8b.
- Test the connection, then search for AI / Orbit AI.
- Conversation history is stored locally in this app's browser storage.
- File-grounded prompts can search and read supported text/source files within configured roots.
- AI answers can be saved as drafts after you review and click Save answer as file.

INCLUDED FEATURES
- Command launcher and recent commands
- Google, GitHub, calculator, Windows Calculator, Notepad
- Local file search
- Settings, global shortcut, launch at sign-in, custom HTTPS commands
- Extension/command pack architecture
- Orbit AI with Ollama or OpenAI-compatible endpoint
- Conversation history, AI connection test, save-answer-as-draft
- Bounded file retrieval for file-grounded prompts

TECH STACK
Electron, React, TypeScript, Vite, Node.js, Ollama/OpenAI-compatible chat API.

If setup fails, send the complete terminal error. Do not copy individual files into an older Orbit folder.
