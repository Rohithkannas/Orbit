# Orbit v0.7.0 — Two Core Features

This build intentionally keeps only two user-facing features:

1. **File Search** — searches the project directory launched by Electron first, then the user's `Orbit`, Desktop, Documents, and Downloads folders. It searches filenames and matching paths, and skips heavyweight/system directories. Search requires at least two characters. Select a result and press Enter (or click it) to open it.
2. **Settings** — saves theme preferences locally and exposes global shortcut and launch-at-sign-in settings through the Electron bridge.

Other commands have been removed from the command catalogue so the interface stays focused.

## Windows setup

Extract the ZIP into a new folder. The `package.json` must be directly inside that extracted folder (not in a second nested folder). In PowerShell in that folder, run:

```powershell
if (-not (Test-Path .\package.json)) { throw 'Open PowerShell in the folder containing package.json.' }
(Get-Content .\package.json -Raw | ConvertFrom-Json).version
npm install
npm run build
if ($LASTEXITCODE -eq 0) { npm run desktop }
```

The dev server uses port `5175` to avoid clashing with older Orbit instances on ports 5173/5174. Close old Orbit windows and dev terminals before testing.
