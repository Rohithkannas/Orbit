import type { CommandPack } from "./types";
import productivityPack from "./productivity";

/** Orbit v0.7 deliberately ships only the two core features: File Search and Settings. */
export const commandPacks: CommandPack[] = [productivityPack];
